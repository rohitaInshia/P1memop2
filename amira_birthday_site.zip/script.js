
document.getElementById('surpriseBtn').addEventListener('click', function () {
  document.getElementById('cake').classList.add('show');
  document.getElementById('balloons').classList.add('show');
  document.getElementById('flowers').classList.add('show');
  document.getElementById('snake').classList.add('show');
  document.getElementById('jewelry').classList.add('show');
  document.getElementById('wish').classList.add('show');
  document.getElementById('birthdayMusic').play();

  const wishes = [
    "Wishing you a day filled with love and cheer!",
    "Hope your birthday is as special as you are!",
    "Many many happy returns of the day!",
    "Have a magical birthday, Amira!",
    "Stay blessed and happy always!"
  ];
  const randomWish = wishes[Math.floor(Math.random() * wishes.length)];
  document.getElementById('wish').innerText = randomWish;
});
